import "bootstrap/dist/css/bootstrap.min.css";
import 'bootstrap/dist/js/bootstrap.bundle.min'; // Import Bootstrap JavaScript
import React from "react";
import { Link, Route, BrowserRouter as Router, Routes } from "react-router-dom";
import BankingSystem from "./BankingSystem"; // Import the new banking system component
import Home from "./Home";
import Login from "./Login";
import lofo from "./images/sco logo.jpg";

function App() {




  const About = () => (
    <div className="container mt-5">
      <h2 className="text-center mb-4"> Scotiabank Bank of Canada</h2>
      <p className="lead text-center">
        scotiabank Bank of Canada is dedicated to providing excellent service to all our clients.
      </p>
    </div>
  );

  return (
    <Router>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
        <a className="navbar-brand" href="#">
            <img 
              src={lofo} 
              alt="Scotiabank Logo" 
              width="100" 
              height="70" 
            />
          </a>
          <div className="collapse navbar-collapse">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/about">About</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/login">Login</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/bank">Banking System</Link>
              </li>
            </ul>
            <div className="collapse navbar-collapse" id="navbarNav">
            <form className="d-flex" role="search">
              <input 
                className="form-control me-2" 
                type="search" 
                placeholder="Search" 
                aria-label="Search" 
              />
              <button className="btn btn-outline-success" type="submit">Search</button>
            </form>
          </div>
          </div>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login />} />
        <Route path="/bank" element={<BankingSystem />} />
      </Routes>
    </Router>
  );
}

export default App;
