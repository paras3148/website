import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min'; // Import Bootstrap JavaScript
import React from 'react';
import './Home.css';
import carouselImage3 from './images/build.jpg'; // Replace with your image paths
import carouselImage2 from './images/scotiabank-main.jpg'; // Replace with your image paths

const Home = () => {
  return (
    <div>

      {/* Carousel Section */}
      <div className='container' id='carousel'> <div id="carouselExample" className="carousel slide">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img 
              src={carouselImage2} 
              className="d-block w-100" 
              alt="Slide 2" 
            />
          </div>
          <div className="carousel-item">
            <img 
              src={carouselImage3} 
              className="d-block w-100" 
              alt="Slide 3" 
            />
          </div>
        </div>
        <button 
          className="carousel-control-prev" 
          type="button" 
          data-bs-target="#carouselExample" 
          data-bs-slide="prev"
        >
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button 
          className="carousel-control-next" 
          type="button" 
          data-bs-target="#carouselExample" 
          data-bs-slide="next"
        >
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div></div>
     

      
      <section className="visa-types py-5">
  <div className="container">
    <h2 className="text-center mb-4">Various Types of Visa Cards</h2>
    <div className="row">
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Standard Visa Card</h5>
            <p>Learn about Standard Visa Cards.</p>
          </div>
        </div>
      </div>
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Rewards Visa Card</h5>
            <p>Learn about Rewards Visa Cards.</p>
          </div>
        </div>
      </div>
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Travel Visa Card</h5>
            <p>Learn about Travel Visa Cards.</p>
          </div>
        </div>
      </div>
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Cashback Visa Card</h5>
            <p>Learn about Cashback Visa Cards.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<section className="student-discounts py-5">
  <div className="container">
    <h2 className="text-center mb-4">Various Student Discounts</h2>
    <div className="row">
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Discount on Textbooks</h5>
            <p>Learn about discounts on textbooks for students.</p>
          </div>
        </div>
      </div>
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Food & Dining Discounts</h5>
            <p>Discover discounts on food and dining options for students.</p>
          </div>
        </div>
      </div>
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Technology & Software Discounts</h5>
            <p>Find out about discounts on technology and software for students.</p>
          </div>
        </div>
      </div>
      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Travel Discounts</h5>
            <p>Explore travel discounts available to students.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

      {/* Footer Section */}
      <footer className="footer-section py-5 bg-light">
        <div className="container text-center">
          <p className="text-muted">Build a plan for your future with Scotiabank</p>
          <button className="btn btn-primary">Book an Appointment</button>
          <button className="btn btn-outline-secondary">Contact Us</button>
        </div>
      </footer>
    </div>
  );
};

export default Home;
